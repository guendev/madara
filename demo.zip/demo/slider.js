module.exports = [
  {
    src: '/images/banner/01.jpeg',
    href: 'javascript:void(0)',
    target: '_blank',
    text: 'Demo 1'
  },
  {
    src: '/images/banner/01.jpeg',
    href: 'javascript:void(0)',
    target: '_blank',
    text: 'Demo 2'
  }
]
